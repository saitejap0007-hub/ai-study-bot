﻿import os
import sys
import io
import json
import unittest
from datetime import date, timedelta

# Ensure project root is in sys.path
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

import docx
from backend.app import create_app
from backend.database import init_db, get_db_connection
from backend.services.extractor import extract_text
import wsgi

class TestAIStudyBuddySystem(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = create_app()
        cls.app.config["TESTING"] = True
        cls.client = cls.app.test_client()
        init_db()

    def test_01_health_and_status(self):
        """Test 1: GET /health and GET /api/status"""
        res_health = self.client.get("/health")
        self.assertEqual(res_health.status_code, 200)
        self.assertEqual(res_health.get_json(), {"status": "ok"})

        res_status = self.client.get("/api/status")
        self.assertEqual(res_status.status_code, 200)
        data = res_status.get_json()
        self.assertEqual(data.get("status"), "online")
        self.assertEqual(data.get("app"), "AI Study Buddy")

    def test_02_wsgi_app_export(self):
        """Test 2: WSGI app export check"""
        self.assertTrue(hasattr(wsgi, "app"))
        self.assertIsNotNone(wsgi.app)
        self.assertEqual(wsgi.app.name, "backend.app")

    def test_03_text_extraction(self):
        """Test 3: Multi-format text extraction (TXT, DOCX, PDF)"""
        tmp_dir = os.path.join(PROJECT_ROOT, "uploads")
        os.makedirs(tmp_dir, exist_ok=True)

        # 1. TXT
        txt_path = os.path.join(tmp_dir, "test_doc.txt")
        with open(txt_path, "w", encoding="utf-8") as f:
            f.write("Operating Systems manage computer hardware and software resources. The CPU scheduler allocates time.")
        txt_out = extract_text(txt_path)
        self.assertIn("Operating Systems", txt_out)
        if os.path.exists(txt_path): os.remove(txt_path)

        # 2. DOCX
        docx_path = os.path.join(tmp_dir, "test_doc.docx")
        doc = docx.Document()
        doc.add_paragraph("Database Management Systems store and retrieve relational data.")
        doc.add_paragraph("SQL is defined as Structured Query Language.")
        doc.save(docx_path)
        docx_out = extract_text(docx_path)
        self.assertIn("Database Management Systems", docx_out)
        if os.path.exists(docx_path): os.remove(docx_path)

        # 3. PDF
        pdf_path = os.path.join(tmp_dir, "test_doc.pdf")
        minimal_pdf = b"""%PDF-1.4
1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj
2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj
3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >> endobj
4 0 obj << /Length 55 >> stream
BT /F1 12 Tf 100 700 Td (Lecture Notes on Artificial Intelligence) Tj ET
endstream
endobj
5 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj
xref
0 6
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
0000000244 00000 n 
0000000350 00000 n 
trailer << /Size 6 /Root 1 0 R >>
startxref
427
%%EOF"""
        with open(pdf_path, "wb") as f:
            f.write(minimal_pdf)
        pdf_out = extract_text(pdf_path)
        self.assertIn("Lecture Notes on Artificial Intelligence", pdf_out)
        if os.path.exists(pdf_path): os.remove(pdf_path)

    def test_04_multi_upload_collision_immunity(self):
        """Test 4: Multi-document upload & collision-proof file naming"""
        content1 = b"Machine Learning algorithms learn patterns from training datasets. Supervised learning requires labeled data."
        content2 = b"Deep Learning neural networks utilize multi-layer perceptrons. Backpropagation computes gradients."

        # Upload first file
        res1 = self.client.post("/api/materials/upload", data={
            "file": (io.BytesIO(content1), "lecture_notes.txt")
        }, content_type="multipart/form-data")
        self.assertEqual(res1.status_code, 201)
        data1 = res1.get_json()["material"]

        # Upload second file with EXACT same original filename
        res2 = self.client.post("/api/materials/upload", data={
            "file": (io.BytesIO(content2), "lecture_notes.txt")
        }, content_type="multipart/form-data")
        self.assertEqual(res2.status_code, 201)
        data2 = res2.get_json()["material"]

        # Assert different IDs and different stored filenames (collision immunity)
        self.assertNotEqual(data1["id"], data2["id"])
        self.assertNotEqual(data1["stored_filename"], data2["stored_filename"])
        self.assertEqual(data1["original_filename"], "lecture_notes.txt")
        self.assertEqual(data2["original_filename"], "lecture_notes.txt")

        # Save material_id for subsequent tests
        TestAIStudyBuddySystem.test_mat_id = data1["id"]
        TestAIStudyBuddySystem.test_mat_id_2 = data2["id"]

    def test_05_material_library_listing_and_retrieval(self):
        """Test 5: Material library listing and single material retrieval"""
        res = self.client.get("/api/materials")
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIn("materials", data)
        self.assertGreaterEqual(len(data["materials"]), 2)

        # Retrieve specific material
        mat_id = TestAIStudyBuddySystem.test_mat_id
        res_single = self.client.get(f"/api/materials/{mat_id}")
        self.assertEqual(res_single.status_code, 200)
        mat_data = res_single.get_json()["material"]
        self.assertEqual(mat_data["id"], mat_id)
        self.assertIn("extracted_text", mat_data)
        self.assertGreater(len(mat_data["extracted_text"]), 10)

    def test_06_ai_summary(self):
        """Test 6: AI Summary & revision notes generation"""
        mat_id = TestAIStudyBuddySystem.test_mat_id
        res = self.client.post(f"/api/materials/{mat_id}/summary", json={"summary_type": "detailed"})
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIn("summary", data)
        self.assertIn("key_concepts", data)
        self.assertIn("definitions", data)
        self.assertIn("formulas", data)
        self.assertIn("exam_points", data)
        self.assertGreater(len(data["summary"]), 20)

    def test_07_important_questions(self):
        """Test 7: Important Questions engine (2-Mark, 5-Mark, 10-Mark)"""
        mat_id = TestAIStudyBuddySystem.test_mat_id
        res = self.client.post(f"/api/materials/{mat_id}/questions")
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIn("questions", data)
        questions = data["questions"]
        self.assertGreaterEqual(len(questions), 1)

        categories = {q["mark_category"] for q in questions}
        self.assertTrue(2 in categories or 5 in categories or 10 in categories)
        for q in questions:
            self.assertIn("question_text", q)
            self.assertIn("marking_guide", q)
            self.assertIn("answer", q)

    def test_08_dynamic_quiz_generation(self):
        """Test 8: Dynamic AI Quiz generation & 4-option MCQ structure"""
        mat_id = TestAIStudyBuddySystem.test_mat_id
        res = self.client.post(f"/api/materials/{mat_id}/quiz", json={"num_questions": 4})
        self.assertEqual(res.status_code, 201)
        data = res.get_json()
        self.assertIn("quiz_id", data)
        self.assertIn("questions", data)
        self.assertGreaterEqual(len(data["questions"]), 1)

        q = data["questions"][0]
        self.assertIn("question", q)
        self.assertIn("option_a", q)
        self.assertIn("option_b", q)
        self.assertIn("option_c", q)
        self.assertIn("option_d", q)
        self.assertIn(q["correct_option"], ["A", "B", "C", "D"])
        self.assertIn("explanation", q)

        TestAIStudyBuddySystem.active_quiz_id = data["quiz_id"]
        TestAIStudyBuddySystem.quiz_questions = data["questions"]

    def test_09_quiz_submission_and_grading(self):
        """Test 9: Quiz submission and grading logic"""
        quiz_id = TestAIStudyBuddySystem.active_quiz_id
        questions = TestAIStudyBuddySystem.quiz_questions

        # Submit answers: answer first correctly, second incorrectly if multiple
        answers = {}
        if len(questions) > 0:
            answers[str(questions[0]["id"])] = questions[0]["correct_option"]
        if len(questions) > 1:
            # deliberately select wrong option
            wrong_opt = "A" if questions[1]["correct_option"] != "A" else "B"
            answers[str(questions[1]["id"])] = wrong_opt

        res = self.client.post("/api/quiz/submit", json={
            "quiz_id": quiz_id,
            "answers": answers
        })
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIn("score", data)
        self.assertIn("total", data)
        self.assertIn("percentage", data)
        self.assertIn("weak_topics", data)
        self.assertIn("strong_topics", data)
        self.assertIn("breakdown", data)

    def test_10_flashcards_deck(self):
        """Test 10: 3D Flashcards generation and status updating"""
        mat_id = TestAIStudyBuddySystem.test_mat_id
        res = self.client.post(f"/api/materials/{mat_id}/flashcards", json={"count": 5})
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIn("flashcards", data)
        self.assertGreaterEqual(len(data["flashcards"]), 1)

        card = data["flashcards"][0]
        self.assertIn("front", card)
        self.assertIn("back", card)

        # Update status to known
        res_put = self.client.put(f"/api/flashcards/{card['id']}/status", json={"status": "known"})
        self.assertEqual(res_put.status_code, 200)
        self.assertEqual(res_put.get_json()["status"], "known")

    def test_11_tutor_chat(self):
        """Test 11: Context-aware AI tutor grounded response"""
        mat_id = TestAIStudyBuddySystem.test_mat_id
        res = self.client.post(f"/api/materials/{mat_id}/tutor", json={
            "message": "Explain supervised learning for 5 marks in an exam."
        })
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIn("response", data)
        self.assertIn("conversation_id", data)
        self.assertGreater(len(data["response"]), 30)

    def test_12_study_planner(self):
        """Test 12: Date-aware study planner calendar calculations"""
        mat_id = TestAIStudyBuddySystem.test_mat_id
        target_exam = (date.today() + timedelta(days=10)).strftime("%Y-%m-%d")
        
        res = self.client.post("/api/planner/generate", json={
            "material_id": mat_id,
            "exam_date": target_exam,
            "daily_minutes": 120
        })
        self.assertEqual(res.status_code, 201)
        data = res.get_json()
        self.assertEqual(data["days_remaining"], 10)
        self.assertEqual(data["daily_minutes"], 120)
        self.assertIn("breakdown", data)
        self.assertEqual(data["breakdown"]["study_minutes"], 60)
        self.assertEqual(data["breakdown"]["practice_minutes"], 30)
        self.assertIn("schedule", data)
        self.assertEqual(len(data["schedule"]), 10)

    def test_13_exam_crash_mode(self):
        """Test 13: Adaptive last-minute exam crash mode"""
        mat_id = TestAIStudyBuddySystem.test_mat_id
        res = self.client.post("/api/exam/generate", json={
            "material_id": mat_id,
            "hours_remaining": 2.0
        })
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(data["hours_remaining"], 2.0)
        self.assertEqual(data["total_minutes"], 120)
        self.assertIn("priority_checklist", data)
        self.assertIn("time_allocation", data)
        self.assertIn("must_know_facts", data)

    def test_14_progress_and_search(self):
        """Test 14: Analytics stats, weak/strong topics, and global search"""
        # Progress stats
        res_stats = self.client.get("/api/progress/stats")
        self.assertEqual(res_stats.status_code, 200)
        stats = res_stats.get_json()
        self.assertGreaterEqual(stats["materials_count"], 1)

        # Topics
        res_topics = self.client.get("/api/progress/topics")
        self.assertEqual(res_topics.status_code, 200)
        topics = res_topics.get_json()
        self.assertIn("weak_topics", topics)
        self.assertIn("strong_topics", topics)

        # Search
        res_search = self.client.get("/api/search?q=learning")
        self.assertEqual(res_search.status_code, 200)
        search_data = res_search.get_json()
        self.assertIn("results", search_data)
        self.assertGreaterEqual(len(search_data["results"]), 1)

    def test_15_material_deletion_cleanup(self):
        """Test 15: Material deletion and storage cleanup"""
        mat_id = TestAIStudyBuddySystem.test_mat_id_2
        res = self.client.delete(f"/api/materials/{mat_id}")
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.get_json()["message"], "Material deleted successfully")

        # Verify 404 after deletion
        res_check = self.client.get(f"/api/materials/{mat_id}")
        self.assertEqual(res_check.status_code, 404)

if __name__ == "__main__":
    unittest.main(verbosity=2)
