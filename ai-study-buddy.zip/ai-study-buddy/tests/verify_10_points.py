from dotenv import load_dotenv
load_dotenv()
import urllib.request, json, os

BASE = 'http://127.0.0.1:5000'

# 1. Read key
key = os.environ.get('GEMINI_API_KEY', '').strip()
print('1. Backend read GEMINI_API_KEY:', bool(key), f'({key[:6]}...{key[-4:]})' if key else 'None')

# 2 & 3. Test connection endpoint
req = urllib.request.Request(f'{BASE}/api/settings/test', data=json.dumps({'engine': 'gemini', 'api_key': key}).encode('utf-8'), headers={'Content-Type': 'application/json'})
try:
    with urllib.request.urlopen(req) as res:
        test_res = json.loads(res.read().decode())
        print('2 & 3. Connection test endpoint response: success =', test_res.get('success'), '| message =', test_res.get('message') or test_res.get('error'))
except urllib.error.HTTPError as e:
    err_body = e.read().decode()
    print('2 & 3. Connection test handled error HTTP', e.code, err_body[:120])

# 4. Check existing materials / upload PDF analysis
with urllib.request.urlopen(f'{BASE}/api/materials') as res:
    mats = json.loads(res.read().decode())['materials']
    print('4. Materials available in library:', len(mats))
    mat = mats[0] if mats else None
    if mat:
        print('4. PDF Analyzed - Title:', mat['title'], '| Pages:', mat.get('page_count'), '| Chars:', mat.get('char_count'), '| Status:', mat.get('status'))

# 5. Generate Summary
if mat:
    mid = mat['id']
    s_req = urllib.request.Request(f'{BASE}/api/materials/{mid}/summary', data=json.dumps({'summary_type': 'quick', 'force_regenerate': True}).encode('utf-8'), headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(s_req) as s_res:
        s_data = json.loads(s_res.read().decode())
        print('5. Summary generated: length =', len(s_data.get('summary', '')), '| Key concepts =', len(s_data.get('key_concepts', [])))

# 6. Generate Questions
if mat:
    mid = mat['id']
    q_req = urllib.request.Request(f'{BASE}/api/materials/{mid}/questions', data=json.dumps({'force_regenerate': True}).encode('utf-8'), headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(q_req) as q_res:
        q_data = json.loads(q_res.read().decode())
        print('6. Questions generated:', len(q_data.get('questions', [])))

# 7. Generate Quiz
if mat:
    mid = mat['id']
    qz_req = urllib.request.Request(f'{BASE}/api/materials/{mid}/quiz', data=json.dumps({'num_questions': 5, 'difficulty': 'Medium'}).encode('utf-8'), headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(qz_req) as qz_res:
        qz_data = json.loads(qz_res.read().decode())
        print('7. Quiz generated: ID =', qz_data.get('quiz_id'), '| Total questions =', len(qz_data.get('questions', [])))

# 8. API Error handling verification: send invalid request
bad_req = urllib.request.Request(f'{BASE}/api/materials/999999/summary', data=json.dumps({}).encode('utf-8'), headers={'Content-Type': 'application/json'})
try:
    with urllib.request.urlopen(bad_req) as res:
        print('8. Unexpected success')
except urllib.error.HTTPError as e:
    print('8. API error handled properly: HTTP', e.code, json.loads(e.read().decode()))

# 9. Key not exposed to frontend: check /api/settings response
with urllib.request.urlopen(f'{BASE}/api/settings') as res:
    settings_data = json.loads(res.read().decode())
    raw_key = key
    key_in_settings = bool(raw_key and raw_key in json.dumps(settings_data))
    print('9. Raw key exposed in /api/settings response:', key_in_settings)
    print('   Masked key returned to client UI:', settings_data.get('gemini_masked'))

# 10. Key not printed in logs check: check wsgi log
with open(r'C:\Users\kille\.gemini\antigravity\brain\29ad3d98-1a85-4f41-a8da-e59f24b8f059\.system_generated\tasks\task-809.log', 'r') as f:
    log_content = f.read()
    key_in_log = bool(raw_key and raw_key in log_content)
    print('10. Raw key found in server task log:', key_in_log)
