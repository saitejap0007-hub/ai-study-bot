﻿import os
import sys
import io
import unittest
import tempfile
import pymupdf
from datetime import date, timedelta

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from backend.app import create_app
from backend.database import init_db, get_db_connection
from backend.services.extractor import extract_document, validate_file_integrity
from backend.services.chunker import split_text_into_chunks, chunk_and_store_document, search_chunks, get_representative_chunks
from backend.services import ai_service

def make_pdf(pages_text: list, add_image: bool = False, scanned_only: bool = False) -> bytes:
    doc = pymupdf.open()
    for idx, txt in enumerate(pages_text):
        page = doc.new_page(width=595, height=842) # A4
        if not scanned_only and txt:
            page.insert_text((50, 72), f"Page {idx+1}: {txt}", fontsize=11)
        if add_image or scanned_only:
            rect = pymupdf.Rect(50, 100, 450, 500)
            page.draw_rect(rect, color=(0.2, 0.4, 0.8), fill=(0.9, 0.95, 1.0))
            page.draw_line((50, 100), (450, 500), color=(0.5, 0.5, 0.5))
    stream = doc.tobytes()
    doc.close()
    return stream

class TestDocumentProcessingPipeline(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = create_app()
        cls.app.config["TESTING"] = True
        cls.client = cls.app.test_client()
        init_db()

    def test_01_very_small_pdf(self):
        """TEST 1: Very small text PDF"""
        pdf_bytes = make_pdf(["Short concept note on thermodynamics."])
        res = self.client.post("/api/materials/upload", data={
            "file": (io.BytesIO(pdf_bytes), "small.pdf")
        }, content_type="multipart/form-data")
        self.assertEqual(res.status_code, 201)
        mat = res.get_json()["material"]
        self.assertEqual(mat["status"], "ready")
        self.assertGreater(mat["char_count"], 10)

    def test_02_normal_academic_pdf(self):
        """TEST 2: Normal academic PDF with multiple concepts"""
        text = (
            "Computer Architecture & Microprocessors.\n\n"
            "The Central Processing Unit (CPU) contains the Arithmetic Logic Unit (ALU), Control Unit, and Registers.\n"
            "Cache memory operates on spatial and temporal locality principles to minimize memory latency."
        )
        pdf_bytes = make_pdf([text])
        res = self.client.post("/api/materials/upload", data={
            "file": (io.BytesIO(pdf_bytes), "computer_architecture.pdf")
        }, content_type="multipart/form-data")
        self.assertEqual(res.status_code, 201)
        mat = res.get_json()["material"]
        self.assertIn("Architecture", mat["title"])
        self.assertEqual(mat["page_count"], 1)

    def test_03_large_academic_pdf(self):
        """TEST 3: Large academic PDF (15 pages)"""
        pages = [
            f"Chapter {i}: Advanced Neural Networks.\nDeep Learning layer {i} processes feature maps and computes non-linear activations."
            for i in range(1, 16)
        ]
        pdf_bytes = make_pdf(pages)
        res = self.client.post("/api/materials/upload", data={
            "file": (io.BytesIO(pdf_bytes), "large_neural_nets.pdf")
        }, content_type="multipart/form-data")
        self.assertEqual(res.status_code, 201)
        mat = res.get_json()["material"]
        self.assertEqual(mat["page_count"], 15)
        self.assertGreater(mat["chunk_count"], 0)
        TestDocumentProcessingPipeline.large_mat_id = mat["id"]

    def test_04_very_large_pdf(self):
        """TEST 4: Very large multi-page PDF (40 pages)"""
        pages = [
            f"Volume {i}: Principles of Distributed Operating Systems.\nConsensus protocols like Raft and Paxos ensure replicated state machine consistency."
            for i in range(1, 41)
        ]
        pdf_bytes = make_pdf(pages)
        res = self.client.post("/api/materials/upload", data={
            "file": (io.BytesIO(pdf_bytes), "very_large_distributed.pdf")
        }, content_type="multipart/form-data")
        self.assertEqual(res.status_code, 201)
        mat = res.get_json()["material"]
        self.assertEqual(mat["page_count"], 40)
        self.assertGreaterEqual(mat["chunk_count"], 10)

    def test_05_pdf_with_many_pages(self):
        """TEST 5: PDF with many pages (> 25 pages)"""
        pages = [f"Lecture Slide {i}: Software Engineering Lifecycle models." for i in range(1, 30)]
        pdf_bytes = make_pdf(pages)
        res = self.client.post("/api/materials/upload", data={
            "file": (io.BytesIO(pdf_bytes), "software_eng.pdf")
        }, content_type="multipart/form-data")
        self.assertEqual(res.status_code, 201)
        self.assertEqual(res.get_json()["material"]["page_count"], 29)

    def test_06_pdf_headings_paragraphs(self):
        """TEST 6: PDF with headings and paragraphs"""
        text = (
            "# Introduction to Compiler Design\n\n"
            "## Lexical Analysis\n"
            "Lexical analysis is defined as the first phase of a compiler which converts characters into tokens.\n\n"
            "## Syntax Analysis\n"
            "Syntax analysis constructs the parse tree according to formal context-free grammars."
        )
        pdf_bytes = make_pdf([text])
        res = self.client.post("/api/materials/upload", data={
            "file": (io.BytesIO(pdf_bytes), "compiler_design.pdf")
        }, content_type="multipart/form-data")
        self.assertEqual(res.status_code, 201)
        mat = res.get_json()["material"]
        self.assertEqual(mat["status"], "ready")

    def test_07_pdf_containing_tables(self):
        """TEST 7: PDF containing tables"""
        table_text = (
            "Process Scheduling Metrics\n\n"
            "PID | Arrival Time | Burst Time | Priority\n"
            "P1  | 0ms          | 8ms        | High\n"
            "P2  | 1ms          | 4ms        | Medium\n"
            "P3  | 2ms          | 9ms        | Low\n"
        )
        pdf_bytes = make_pdf([table_text])
        res = self.client.post("/api/materials/upload", data={
            "file": (io.BytesIO(pdf_bytes), "scheduling_table.pdf")
        }, content_type="multipart/form-data")
        self.assertEqual(res.status_code, 201)
        mat_id = res.get_json()["material"]["id"]
        res_get = self.client.get(f"/api/materials/{mat_id}")
        self.assertIn("Burst Time", res_get.get_json()["material"]["extracted_text"])

    def test_08_pdf_containing_images(self):
        """TEST 8: PDF containing text alongside images"""
        text = "Robotics Kinematics: The forward kinematics computes end-effector position from joint angles."
        pdf_bytes = make_pdf([text], add_image=True)
        res = self.client.post("/api/materials/upload", data={
            "file": (io.BytesIO(pdf_bytes), "robotics_image.pdf")
        }, content_type="multipart/form-data")
        self.assertEqual(res.status_code, 201)
        mat = res.get_json()["material"]
        self.assertIn("Kinematics", mat["extracted_text"])

    def test_09_scanned_image_only_pdf(self):
        """TEST 9: Scanned/image-only PDF detection"""
        pdf_bytes = make_pdf(["", "", ""], scanned_only=True)
        res = self.client.post("/api/materials/upload", data={
            "file": (io.BytesIO(pdf_bytes), "scanned_doc.pdf")
        }, content_type="multipart/form-data")
        self.assertEqual(res.status_code, 201)
        mat = res.get_json()["material"]
        self.assertEqual(mat["status"], "scanned_ocr_required")
        self.assertTrue(mat["is_scanned"])

    def test_10_empty_pdf(self):
        """TEST 10: Empty PDF (0 bytes) rejected with user-friendly error"""
        empty_bytes = b""
        res = self.client.post("/api/materials/upload", data={
            "file": (io.BytesIO(empty_bytes), "empty.pdf")
        }, content_type="multipart/form-data")
        self.assertEqual(res.status_code, 400)
        self.assertIn("empty", res.get_json()["error"])

    def test_11_corrupted_pdf(self):
        """TEST 11: Corrupted PDF file rejected gracefully"""
        corrupted_bytes = b"%PDF-1.4\nJUNKCORRUPTDATA\x00\xff\xfeRANDOMBYTESNOTVALIDPDFSTRUCTURE"
        res = self.client.post("/api/materials/upload", data={
            "file": (io.BytesIO(corrupted_bytes), "corrupt.pdf")
        }, content_type="multipart/form-data")
        if res.status_code == 400:
            self.assertIn("corrupt", res.get_json()["error"].lower())
        else:
            self.assertIn("corrupt", res.get_json()["materials"][0]["status"])

    def test_12_truncated_pdf_stream_fix(self):
        """TEST 12: Truncated stream ('Stream has ended unexpectedly') fix verification"""
        truncated_bytes = b"""%PDF-1.4
1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj
2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj
3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >> endobj
4 0 obj << /Length 250 >> stream
BT /F1 12 Tf 100 700 Td (Verified Fix: Academic lecture note recovered despite truncated stream EOF) Tj ET
"""
        res = self.client.post("/api/materials/upload", data={
            "file": (io.BytesIO(truncated_bytes), "truncated_lecture.pdf")
        }, content_type="multipart/form-data")
        self.assertEqual(res.status_code, 201)
        mat = res.get_json()["material"]
        self.assertEqual(mat["status"], "ready")
        self.assertIn("Verified Fix", mat["extracted_text"])

    def test_13_unsupported_file_type(self):
        """TEST 13: Unsupported file type rejected"""
        res = self.client.post("/api/materials/upload", data={
            "file": (io.BytesIO(b"executable content"), "malware.exe")
        }, content_type="multipart/form-data")
        self.assertEqual(res.status_code, 400)
        self.assertIn("not currently supported", res.get_json()["error"])

    def test_14_file_exceeding_size_limit(self):
        """TEST 14: File exceeding configured limit rejected"""
        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as f:
            f.write(b"%PDF-1.4\n" + b"A" * 1024)
            path = f.name
            
        old_val = os.environ.get("MAX_UPLOAD_SIZE_MB")
        try:
            os.environ["MAX_UPLOAD_SIZE_MB"] = "0"
            import importlib
            import backend.services.extractor as ext_mod
            importlib.reload(ext_mod)
            with self.assertRaises(ValueError) as ctx:
                ext_mod.validate_file_integrity(path)
            self.assertIn("exceeds the maximum", str(ctx.exception))
        finally:
            if old_val: os.environ["MAX_UPLOAD_SIZE_MB"] = old_val
            else: os.environ.pop("MAX_UPLOAD_SIZE_MB", None)
            import importlib
            import backend.services.extractor as ext_mod
            importlib.reload(ext_mod)
            if os.path.exists(path): os.remove(path)

    def test_15_unusual_characters_and_math(self):
        """TEST 15: PDF with unusual characters, Greek letters, math symbols"""
        text = "Quantum Mechanics: The wave equation is defined by i*hbar * d(psi)/dt = H(psi). Alpha: \u03b1, Beta: \u03b2, Gamma: \u03b3."
        pdf_bytes = make_pdf([text])
        res = self.client.post("/api/materials/upload", data={
            "file": (io.BytesIO(pdf_bytes), "quantum_math.pdf")
        }, content_type="multipart/form-data")
        self.assertEqual(res.status_code, 201)
        self.assertIn("Quantum", res.get_json()["material"]["extracted_text"])

    def test_16_very_little_extractable_text(self):
        """TEST 16: PDF with very little extractable text flagged appropriately"""
        pdf_bytes = make_pdf(["Hi", "Ok", ""], scanned_only=False)
        res = self.client.post("/api/materials/upload", data={
            "file": (io.BytesIO(pdf_bytes), "sparse.pdf")
        }, content_type="multipart/form-data")
        self.assertEqual(res.status_code, 201)
        mat = res.get_json()["material"]
        self.assertTrue(mat["is_scanned"] or mat["status"] in ["scanned_ocr_required", "ready"])

    def test_17_multiple_sequential_uploads(self):
        """TEST 17: Multiple sequential uploads with live progress simulation"""
        for i in range(3):
            pdf_bytes = make_pdf([f"Sequential Module {i}: Advanced Graph Algorithms."])
            res = self.client.post("/api/materials/upload", data={
                "file": (io.BytesIO(pdf_bytes), f"graph_module_{i}.pdf")
            }, content_type="multipart/form-data")
            self.assertEqual(res.status_code, 201)

    def test_18_document_isolation_no_mixing(self):
        """TEST 18: Multiple documents processed without content leaking between them"""
        pdf1 = make_pdf(["Document Alpha: Specialized Biochemistry Pathways."])
        pdf2 = make_pdf(["Document Beta: Quantum Cryptography and Entanglement."])

        res1 = self.client.post("/api/materials/upload", data={"file": (io.BytesIO(pdf1), "doc_alpha.pdf")}, content_type="multipart/form-data")
        res2 = self.client.post("/api/materials/upload", data={"file": (io.BytesIO(pdf2), "doc_beta.pdf")}, content_type="multipart/form-data")

        id1 = res1.get_json()["material"]["id"]
        id2 = res2.get_json()["material"]["id"]

        get1 = self.client.get(f"/api/materials/{id1}").get_json()["material"]
        get2 = self.client.get(f"/api/materials/{id2}").get_json()["material"]

        self.assertIn("Biochemistry", get1["extracted_text"])
        self.assertNotIn("Cryptography", get1["extracted_text"])
        self.assertIn("Cryptography", get2["extracted_text"])
        self.assertNotIn("Biochemistry", get2["extracted_text"])

    def test_19_upload_empty_request(self):
        """TEST 19: Upload empty form request failure handled cleanly"""
        res = self.client.post("/api/materials/upload", data={})
        self.assertEqual(res.status_code, 400)

    def test_20_ai_resilience_on_invalid_keys(self):
        """TEST 20: AI processing fallback works when API keys are absent or invalid"""
        text = "Database normalization reduces data redundancy and improves data integrity through 1NF, 2NF, and 3NF forms."
        res = ai_service.generate_summary(text)
        self.assertIn("summary", res)
        self.assertIn("key_concepts", res)

    def test_21_chunking_preserves_boundaries(self):
        """TEST 21: Document chunking preserves paragraph structure and overlap"""
        sample = "Paragraph 1 on networking protocols.\n\nParagraph 2 on routing tables.\n\nParagraph 3 on socket programming."
        chunks = split_text_into_chunks(sample, page_number=1, chunk_size=80, overlap=20)
        self.assertGreaterEqual(len(chunks), 2)
        self.assertTrue(any("networking" in c["content"] for c in chunks))

    def test_22_chunk_storage_and_query(self):
        """TEST 22: Chunk persistence in SQLite document_chunks table"""
        mat_id = TestDocumentProcessingPipeline.large_mat_id
        chunks = chunk_and_store_document(mat_id, [{"page_number": 1, "text": "Sample chunk storage text."}])
        self.assertEqual(len(chunks), 1)
        res = self.client.get(f"/api/materials/{mat_id}/chunks")
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.get_json()["total_chunks"], 1)

    def test_23_rag_search_chunks(self):
        """TEST 23: RAG chunk search relevance scoring"""
        mat_id = TestDocumentProcessingPipeline.large_mat_id
        pages = [
            {"page_number": 1, "text": "Supervised learning models use labeled data points."},
            {"page_number": 2, "text": "Unsupervised clustering algorithms group unlabeled vectors."},
            {"page_number": 3, "text": "Reinforcement learning agents optimize cumulative rewards via Q-learning."}
        ]
        chunk_and_store_document(mat_id, pages)
        top_chunks = search_chunks(mat_id, "clustering algorithms", top_k=1)
        self.assertEqual(len(top_chunks), 1)
        self.assertIn("Unsupervised", top_chunks[0]["content"])

    def test_24_representative_chunk_sampling(self):
        """TEST 24: Representative chunk sampling across whole document"""
        mat_id = TestDocumentProcessingPipeline.large_mat_id
        pages = [{"page_number": i, "text": f"Chapter {i} overview on Neural Networks."} for i in range(1, 21)]
        chunk_and_store_document(mat_id, pages)
        rep = get_representative_chunks(mat_id, max_chunks=5)
        self.assertEqual(len(rep), 5)

    def test_25_large_doc_summary_generation(self):
        """TEST 25: Generate summary from large document using chunk aggregation"""
        mat_id = TestDocumentProcessingPipeline.large_mat_id
        res = self.client.post(f"/api/materials/{mat_id}/summary", json={"summary_type": "detailed"})
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIn("summary", data)
        self.assertIn("definitions", data)

    def test_26_large_doc_questions_generation(self):
        """TEST 26: Generate questions from large document"""
        mat_id = TestDocumentProcessingPipeline.large_mat_id
        res = self.client.post(f"/api/materials/{mat_id}/questions")
        self.assertEqual(res.status_code, 200)
        self.assertGreaterEqual(len(res.get_json()["questions"]), 1)

    def test_27_large_doc_quiz_generation(self):
        """TEST 27: Generate dynamic quiz from large document"""
        mat_id = TestDocumentProcessingPipeline.large_mat_id
        res = self.client.post(f"/api/materials/{mat_id}/quiz", json={"num_questions": 4})
        self.assertEqual(res.status_code, 201)
        self.assertEqual(len(res.get_json()["questions"]), 4)

    def test_28_large_doc_flashcards_generation(self):
        """TEST 28: Generate flashcards from large document"""
        mat_id = TestDocumentProcessingPipeline.large_mat_id
        res = self.client.post(f"/api/materials/{mat_id}/flashcards", json={"count": 6})
        self.assertEqual(res.status_code, 200)
        self.assertGreaterEqual(len(res.get_json()["flashcards"]), 1)

    def test_29_large_doc_tutor_rag_retrieval(self):
        """TEST 29: AI Tutor grounded query using RAG chunk search"""
        mat_id = TestDocumentProcessingPipeline.large_mat_id
        res = self.client.post(f"/api/materials/{mat_id}/tutor", json={
            "message": "Explain Neural Networks architecture."
        })
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIn("response", data)
        self.assertGreater(len(data["response"]), 20)

    def test_30_global_search_across_chunks(self):
        """TEST 30: Global search returns matching page and chunk snippet"""
        res = self.client.get("/api/search?q=Neural")
        self.assertEqual(res.status_code, 200)
        results = res.get_json()["results"]
        self.assertGreaterEqual(len(results), 1)
        self.assertTrue(any("Neural" in r["title"] or "Neural" in r["snippet"] or "Neural" in r["description"] for r in results))

if __name__ == "__main__":
    unittest.main(verbosity=2)
