import os
import sys
import unittest
import json

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from backend.app import create_app
from backend.database import init_db

class TestSettingsAndReset(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = create_app()
        cls.app.config["TESTING"] = True
        cls.client = cls.app.test_client()
        init_db()
        cls._orig_gemini = os.environ.get("GEMINI_API_KEY", "")
        cls._orig_openai = os.environ.get("OPENAI_API_KEY", "")
        cls._orig_preferred = os.environ.get("PREFERRED_AI_ENGINE", "gemini")

    @classmethod
    def tearDownClass(cls):
        from backend.routes.settings import save_env_var
        save_env_var("GEMINI_API_KEY", cls._orig_gemini)
        save_env_var("OPENAI_API_KEY", cls._orig_openai)
        save_env_var("PREFERRED_AI_ENGINE", cls._orig_preferred)

    def test_get_settings(self):
        """GET /api/settings should return engine and masked keys"""
        res = self.client.get("/api/settings")
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIn("active_engine", data)
        self.assertIn("preferred_engine", data)
        self.assertIn("has_gemini_key", data)
        self.assertIn("has_openai_key", data)

    def test_save_settings_and_update_env(self):
        """POST /api/settings should update environment variables dynamically"""
        test_payload = {
            "preferred_engine": "gemini",
            "gemini_api_key": "AIzaSyTestKey1234567890abcdef",
            "openai_api_key": "sk-TestOpenAIKey1234567890abcdef"
        }
        res = self.client.post("/api/settings", json=test_payload)
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data.get("success"))
        self.assertEqual(os.environ.get("GEMINI_API_KEY"), "AIzaSyTestKey1234567890abcdef")
        self.assertEqual(os.environ.get("OPENAI_API_KEY"), "sk-TestOpenAIKey1234567890abcdef")

        # Check GET /api/settings shows masked keys
        res_get = self.client.get("/api/settings")
        get_data = res_get.get_json()
        self.assertTrue(get_data["has_gemini_key"])
        self.assertTrue(get_data["has_openai_key"])
        self.assertTrue(get_data["gemini_key_masked"].startswith("AIzaSy"))
        self.assertIn("...", get_data["gemini_key_masked"])

    def test_test_ai_connection_invalid_key(self):
        """POST /api/settings/test should fail gracefully on fake key"""
        res = self.client.post("/api/settings/test", json={"engine": "gemini", "gemini_api_key": "AIzaSyInvalidKey"})
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertFalse(data.get("success"))
        self.assertIn("error", data)

    def test_reset_all_materials(self):
        """POST /api/materials/reset-all should wipe materials and reset database tables"""
        # Upload a dummy txt file first
        import io
        dummy_file = (io.BytesIO(b"Sample lecture material on distributed systems and vector clocks."), "lecture1.txt")
        upload_res = self.client.post("/api/materials/upload", data={"files": [dummy_file]}, content_type="multipart/form-data")
        self.assertIn(upload_res.status_code, (200, 201))

        # Check materials list has at least 1 material
        mats = self.client.get("/api/materials").get_json()["materials"]
        self.assertGreaterEqual(len(mats), 1)

        # Reset all
        reset_res = self.client.post("/api/materials/reset-all")
        self.assertEqual(reset_res.status_code, 200)
        reset_data = reset_res.get_json()
        self.assertTrue(reset_data.get("success"))

        # Verify materials list is now empty
        mats_after = self.client.get("/api/materials").get_json()["materials"]
        self.assertEqual(len(mats_after), 0)

if __name__ == "__main__":
    unittest.main()
