const SummaryController = {
  currentSummaryData: null,
  selectedType: "medium",
  isGenerating: false,

  onMaterialChanged(material) {
    this.currentSummaryData = null;
    if (material) {
      this.loadSummary(material.id);
    } else {
      this.renderEmpty();
    }
  },

  onSectionActivated() {
    if (window.AppState.activeMaterial && !this.currentSummaryData) {
      this.loadSummary(window.AppState.activeMaterial.id);
    }
  },

  async loadSummary(materialId) {
    try {
      const data = await window.API.getSummary(materialId);
      if (data) {
        this.currentSummaryData = data;
        this.renderSummary(data);
      } else {
        this.renderEmpty();
      }
    } catch (e) {
      console.error("Error loading summary:", e);
    }
  },

  async generateSummary(forceRegenerate = false) {
    if (this.isGenerating) return;
    const active = window.AppState.activeMaterial;
    if (!active) {
      window.showToast("Please upload or select a material first", "warning");
      return;
    }

    const area = document.getElementById("summary-content-area");
    const genBtn = document.getElementById("btn-generate-summary");
    this.isGenerating = true;
    if (genBtn) genBtn.disabled = true;

    area.innerHTML = `
      <div style="text-align: center; padding: 60px 20px;">
        <div style="font-size: 36px; animation: spin 1s infinite linear;">⚡</div>
        <h3 style="margin-top: 16px;">Analyzing Document with Google Gemini...</h3>
        <p class="text-muted">Synthesizing concepts, formal definitions, formulas, and high-yield exam takeaways.</p>
      </div>
    `;

    try {
      const data = await window.API.generateSummary(active.id, this.selectedType, forceRegenerate);
      this.currentSummaryData = data;
      this.renderSummary(data);
      window.showToast("Summary notes generated successfully with Gemini!");
    } catch (e) {
      window.showToast(`Generation failed: ${e.message}`, "error");
      this.renderEmpty();
    } finally {
      this.isGenerating = false;
      if (genBtn) genBtn.disabled = false;
    }
  },

  renderEmpty() {
    const area = document.getElementById("summary-content-area");
    if (!area) return;
    area.innerHTML = `
      <div class="empty-state">
        <span class="empty-icon">📝</span>
        <h3>No Summary Generated Yet</h3>
        <p>Select a material and click "Generate Summary" to extract structured study notes with Gemini.</p>
      </div>
    `;
  },

  renderSummary(data) {
    const area = document.getElementById("summary-content-area");
    if (!area) return;

    const titleText = data.title || (window.AppState.activeMaterial ? window.AppState.activeMaterial.title : "Document");
    const conceptsHtml = (data.key_concepts || []).map(c => `<span class="badge badge-indigo" style="font-size: 0.85rem; padding: 6px 14px;">${c}</span>`).join(" ");
    
    const defsHtml = (data.definitions || []).map(d => `
      <div style="background: #fff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 14px; margin-bottom: 10px;">
        <strong style="color: var(--primary); font-size: 0.95rem;">${d.term}:</strong>
        <p style="font-size: 0.9rem; color: #334155; margin-top: 4px;">${d.definition}</p>
      </div>
    `).join("");

    const importantPointsHtml = (data.important_points || []).map(p => `
      <li style="margin-bottom: 8px; font-size: 0.92rem; color: #1e293b;">📌 ${p}</li>
    `).join("");

    const formulasHtml = (data.formulas || []).map(f => `
      <div style="background: #f8fafc; border-left: 4px solid var(--secondary); padding: 12px 16px; margin-bottom: 10px; border-radius: 4px;">
        <code style="font-family: var(--font-mono); font-size: 0.95rem; font-weight: 600; color: #4338ca;">${f.formula}</code>
        <div style="font-size: 0.82rem; color: #64748b; margin-top: 4px;">${f.description}</div>
      </div>
    `).join("");

    const examplesHtml = (data.examples || []).map(ex => `
      <div style="background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 12px 16px; margin-bottom: 10px;">
        <strong style="color: #166534; font-size: 0.9rem;">💡 ${ex.concept}:</strong>
        <p style="font-size: 0.88rem; color: #14532d; margin-top: 4px;">${ex.example}</p>
      </div>
    `).join("");

    const examPointsHtml = (data.exam_points || []).map(p => `
      <li style="margin-bottom: 8px; font-size: 0.92rem; color: #1e293b;">🎯 ${p}</li>
    `).join("");

    const revisionHtml = data.revision_notes ? `
      <div style="background: linear-gradient(135deg, #fdf4ff, #fae8ff); border: 1px solid #f0abfc; border-radius: 8px; padding: 16px; margin-top: 24px;">
        <h3 style="font-size: 1rem; font-weight: 700; color: #86198f; margin-bottom: 6px;">⚡ Last-Minute Rapid Revision Digest</h3>
        <p style="font-size: 0.92rem; color: #701a75; line-height: 1.6; margin: 0;">${data.revision_notes}</p>
      </div>
    ` : "";

    area.innerHTML = `
      <div class="card">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 16px;">
          <div>
            <span class="badge badge-accent" style="margin-bottom: 8px;">Gemini Powered</span>
            <h2 style="font-size: 1.35rem; font-weight: 800; color: var(--primary);">${titleText}</h2>
          </div>
          <button class="btn btn-outline btn-xs" id="btn-force-regenerate-summary" title="Generate fresh summary">🔄 Regenerate</button>
        </div>

        <h3 class="sub-heading" style="margin-top: 0;">Overview</h3>
        <div style="font-size: 1rem; line-height: 1.7; color: #1e293b; margin-bottom: 24px;">
          ${data.summary}
        </div>

        <h3 class="sub-heading">Important Concepts</h3>
        <div style="display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 24px;">
          ${conceptsHtml || "<p class='text-muted'>No key concepts identified.</p>"}
        </div>

        <h3 class="sub-heading">Key Definitions</h3>
        <div style="margin-bottom: 24px;">
          ${defsHtml || "<p class='text-muted'>No definitions extracted.</p>"}
        </div>

        ${data.important_points && data.important_points.length > 0 ? `
          <h3 class="sub-heading">Important Points</h3>
          <ul style="list-style: none; padding-left: 0; margin-bottom: 24px;">
            ${importantPointsHtml}
          </ul>
        ` : ""}

        <h3 class="sub-heading">Formulas & Core Principles</h3>
        <div style="margin-bottom: 24px;">
          ${formulasHtml || "<p class='text-muted'>No mathematical formulas in this document.</p>"}
        </div>

        ${data.examples && data.examples.length > 0 ? `
          <h3 class="sub-heading">Illustrative Examples</h3>
          <div style="margin-bottom: 24px;">
            ${examplesHtml}
          </div>
        ` : ""}

        <h3 class="sub-heading">High-Yield Exam Points</h3>
        <ul style="list-style: none; padding-left: 0; margin-bottom: 24px;">
          ${examPointsHtml || "<p class='text-muted'>No exam points generated.</p>"}
        </ul>

        ${revisionHtml}
      </div>
    `;

    const regenBtn = document.getElementById("btn-force-regenerate-summary");
    if (regenBtn) {
      regenBtn.addEventListener("click", () => this.generateSummary(true));
    }
  },

  copySummary() {
    if (!this.currentSummaryData) {
      window.showToast("No summary available to copy", "warning");
      return;
    }
    const d = this.currentSummaryData;
    let text = `SUMMARY: ${d.title || ''}\n\n${d.summary}\n\nKEY CONCEPTS:\n${(d.key_concepts || []).join(", ")}\n\nEXAM POINTS:\n${(d.exam_points || []).join("\n")}`;
    if (d.revision_notes) text += `\n\nREVISION:\n${d.revision_notes}`;
    navigator.clipboard.writeText(text).then(() => {
      window.showToast("Summary copied to clipboard!");
    });
  },

  exportMarkdown() {
    if (!this.currentSummaryData) {
      window.showToast("No summary available to export", "warning");
      return;
    }
    const d = this.currentSummaryData;
    let md = `# ${d.title || 'Study Material'} – AI Revision Notes\n\n## Summary Overview\n${d.summary}\n\n`;
    md += `## Key Concepts\n${(d.key_concepts || []).map(c => `- ${c}`).join("\n")}\n\n`;
    md += `## Key Definitions\n${(d.definitions || []).map(x => `- **${x.term}**: ${x.definition}`).join("\n")}\n\n`;
    if (d.important_points && d.important_points.length > 0) {
      md += `## Important Points\n${d.important_points.map(p => `- ${p}`).join("\n")}\n\n`;
    }
    if (d.formulas && d.formulas.length > 0) {
      md += `## Formulas & Relations\n${d.formulas.map(f => `- \`${f.formula}\`: ${f.description}`).join("\n")}\n\n`;
    }
    if (d.examples && d.examples.length > 0) {
      md += `## Examples\n${d.examples.map(e => `- **${e.concept}**: ${e.example}`).join("\n")}\n\n`;
    }
    md += `## High-Yield Exam Points\n${(d.exam_points || []).map(p => `- ${p}`).join("\n")}\n\n`;
    if (d.revision_notes) {
      md += `## Rapid Revision Digest\n${d.revision_notes}\n`;
    }

    const blob = new Blob([md], { type: "text/markdown;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `study_notes_${Date.now()}.md`;
    a.click();
    URL.revokeObjectURL(url);
    window.showToast("Markdown exported!");
  }
};

window.SummaryController = SummaryController;

document.addEventListener("DOMContentLoaded", () => {
  const genBtn = document.getElementById("btn-generate-summary");
  const copyBtn = document.getElementById("btn-copy-summary");
  const exportBtn = document.getElementById("btn-export-summary");
  const typeBtns = document.querySelectorAll("#summary-type-group .btn");

  if (genBtn) genBtn.addEventListener("click", () => SummaryController.generateSummary());
  if (copyBtn) copyBtn.addEventListener("click", () => SummaryController.copySummary());
  if (exportBtn) exportBtn.addEventListener("click", () => SummaryController.exportMarkdown());

  typeBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      typeBtns.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      SummaryController.selectedType = btn.getAttribute("data-type");
      if (window.AppState.activeMaterial) {
        SummaryController.generateSummary();
      }
    });
  });
});
