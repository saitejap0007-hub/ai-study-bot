import os
import re
import requests
from flask import Blueprint, request, jsonify

settings_bp = Blueprint("settings", __name__)

ENV_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), ".env")

def mask_key(key: str) -> str:
    if not key or len(key) < 8:
        return ""
    return f"{key[:6]}...{key[-4:]}"

def save_env_var(key_name: str, key_val: str):
    """Persists an environment variable to the .env file and updates os.environ."""
    os.environ[key_name] = key_val
    
    lines = []
    if os.path.exists(ENV_PATH):
        with open(ENV_PATH, "r", encoding="utf-8") as f:
            lines = f.readlines()
            
    found = False
    new_lines = []
    for line in lines:
        if line.startswith(f"{key_name}="):
            new_lines.append(f"{key_name}={key_val}\n")
            found = True
        else:
            new_lines.append(line)
            
    if not found:
        new_lines.append(f"{key_name}={key_val}\n")
        
    with open(ENV_PATH, "w", encoding="utf-8") as f:
        f.writelines(new_lines)

@settings_bp.route("/api/settings", methods=["GET"])
def get_settings():
    gemini_key = os.environ.get("GEMINI_API_KEY", "").strip() or os.environ.get("AI_API_KEY", "").strip()
    openai_key = os.environ.get("OPENAI_API_KEY", "").strip()
    preferred_engine = os.environ.get("PREFERRED_AI_ENGINE", "gemini").strip().lower()

    if gemini_key:
        active_model = os.environ.get("GEMINI_MODEL", "gemini-3.6-flash").strip()
        active_engine = f"Google Gemini ({active_model}) (Active)"
    elif openai_key:
        active_engine = "OpenAI GPT-4o-mini (Active)"
    else:
        active_engine = "Local Educational NLP (Active - Offline Safe)"

    gem_masked = mask_key(gemini_key)
    oai_masked = mask_key(openai_key)

    return jsonify({
        "success": True,
        "has_gemini": bool(gemini_key),
        "has_gemini_key": bool(gemini_key),
        "gemini_masked": gem_masked,
        "gemini_key_masked": gem_masked,
        "has_openai": bool(openai_key),
        "has_openai_key": bool(openai_key),
        "openai_masked": oai_masked,
        "openai_key_masked": oai_masked,
        "preferred_engine": preferred_engine,
        "active_engine": active_engine
    }), 200

@settings_bp.route("/api/settings", methods=["POST"])
def save_settings():
    data = request.get_json(silent=True) or {}
    
    gemini_key = data.get("gemini_api_key")
    openai_key = data.get("openai_api_key")
    preferred_engine = data.get("preferred_engine")

    if gemini_key is not None:
        save_env_var("GEMINI_API_KEY", gemini_key.strip())
    if openai_key is not None:
        save_env_var("OPENAI_API_KEY", openai_key.strip())
    if preferred_engine is not None:
        save_env_var("PREFERRED_AI_ENGINE", preferred_engine.strip().lower())

    g_key = os.environ.get("GEMINI_API_KEY", "").strip() or os.environ.get("AI_API_KEY", "").strip()
    o_key = os.environ.get("OPENAI_API_KEY", "").strip()
    if g_key:
        active_engine = "gemini"
    elif o_key:
        active_engine = "openai"
    else:
        active_engine = "offline"

    return jsonify({
        "success": True,
        "message": "AI configuration saved successfully!",
        "has_gemini": bool(g_key),
        "has_openai": bool(o_key),
        "active_engine": active_engine
    }), 200

@settings_bp.route("/api/settings/test", methods=["POST"])
def test_connection():
    data = request.get_json(silent=True) or {}
    engine = data.get("engine", "gemini").lower()
    test_key = data.get("api_key") or data.get("gemini_api_key") or data.get("openai_api_key") or ""
    test_key = test_key.strip()

    import time
    start_time = time.time()

    if engine == "gemini":
        key = test_key or os.environ.get("GEMINI_API_KEY", "").strip() or os.environ.get("AI_API_KEY", "").strip()
        if not key:
            return jsonify({"success": False, "status": "error", "error": "No Gemini API key provided to test."}), 200

        models_to_try = ["gemini-3.6-flash", "gemini-2.5-flash", "gemini-1.5-flash", "gemini-flash-latest"]
        payload = {"contents": [{"parts": [{"text": "Reply with 'OK'."}]}]}
        last_error = "Unknown error"

        for model_name in models_to_try:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{model_name}:generateContent?key={key}"
            try:
                res = requests.post(url, json=payload, timeout=8)
                latency_ms = int((time.time() - start_time) * 1000)
                if res.status_code == 200:
                    return jsonify({
                        "success": True,
                        "status": "success",
                        "model": model_name,
                        "latency_ms": latency_ms,
                        "message": f"Google Gemini ({model_name}) connection successful! Model is ready."
                    }), 200
                err_data = res.json().get("error", {}) if res.headers.get("content-type", "").startswith("application/json") else {}
                last_error = err_data.get("message") or f"HTTP {res.status_code}: {res.text[:120]}"
            except Exception as e:
                last_error = str(e)

        return jsonify({
            "success": False,
            "status": "error",
            "error": f"Gemini rejected key: {last_error}",
            "message": f"Gemini rejected key: {last_error}"
        }), 200

    elif engine == "openai":
        key = test_key or os.environ.get("OPENAI_API_KEY", "").strip()
        if not key:
            return jsonify({"success": False, "status": "error", "error": "No OpenAI API key provided to test."}), 200

        url = "https://api.openai.com/v1/models"
        headers = {"Authorization": f"Bearer {key}"}
        try:
            res = requests.get(url, headers=headers, timeout=8)
            latency_ms = int((time.time() - start_time) * 1000)
            if res.status_code == 200:
                return jsonify({
                    "success": True,
                    "status": "success",
                    "latency_ms": latency_ms,
                    "message": "OpenAI API connection successful! Models verified."
                }), 200
            return jsonify({
                "success": False,
                "status": "error",
                "error": f"OpenAI rejected key: {res.text[:120]}",
                "message": f"OpenAI rejected key: {res.text[:120]}"
            }), 200
        except Exception as e:
            return jsonify({
                "success": False,
                "status": "error",
                "error": f"Connection failed: {str(e)}",
                "message": f"Connection failed: {str(e)}"
            }), 200

    return jsonify({"success": False, "status": "error", "error": "Unknown engine selected."}), 200
